import multiprocessing as mp
from pathlib import Path

# Hyperiso imports (adapte si besoin)
from pyhyperiso.core.Common.GeneralEnum import Observables, QCDOrder, Model, ParameterType
from pyhyperiso.core.Core.HyperisoMaster import PyHyperisoMaster
from pyhyperiso.core.Core.HyperisoConfig import PyHyperisoConfig, ExternalFlag
from pyhyperiso.core.BusinessLogic.ObservableInterface import PyObservableInterface

from pyhyperiso.core.Statistic.StatisticInterface import StatisticInterface
from pyhyperiso.core.Statistic.StatisticConfig import StatisticConfig


def _init_hyperiso(lha_file_path: str):
    hyp = PyHyperisoMaster()
    config = PyHyperisoConfig(
        flags={
            ExternalFlag.IS_LHA_SPECTRUM: True,
            ExternalFlag.HAS_WILSON_INPUT: False,
            ExternalFlag.HAS_TH_OBSERVABLE_INPUT: False,
            ExternalFlag.HYP_AS_SM_MARTY: True,
        },
        model=Model.SM,
        mty_model_name="MSSM_UFO",
        # mty_model_path=Path("/my/custom/marty/path"),
    )
    hyp.init(lha_file=lha_file_path, config=config)
    return hyp


def stats_worker(lha_file_path: str, selected, out_q: mp.Queue):
    """
    Process séparé: calcule summaries via StatisticInterface.
    """
    try:
        _init_hyperiso(lha_file_path)

        stat_cfg = StatisticConfig(
            obss={o: QCDOrder.NNLO for o in selected},
            p_specs=[],
            MC_draws=200,
            skew_abs_threshold=0.2,
        )
        stat_interface = StatisticInterface(stat_cfg)

        summaries_raw = stat_interface.compute_uncertainties()

        # On renvoie tel quel (pickle). Si les clés sont des objets pybind,
        # ça peut quand même passer. Sinon, convertis en (str(k), v_as_dict).
        out_q.put(("ok", summaries_raw))
    except Exception as e:
        out_q.put(("err", repr(e)))


def compute_centrals_in_main(lha_file_path: str, selected):
    """
    Process principal: calcule les valeurs centrales via PyObservableInterface.
    """
    _init_hyperiso(lha_file_path)

    obs_interface = PyObservableInterface()
    for o in selected:
        obs_interface.add_observable(o, QCDOrder.NNLO, add_dependencies=True)

    centrals = {}
    for o in selected:
        vals = obs_interface.compute_observable(o)
        # vals = vector<ObservableValue> côté pybind ; souvent 1 élément pour non-binned
        centrals[o] = vals
    return centrals


def main():
    lha_file_path = "lha/si_input.flha"

    selected = [
        Observables.BR_BS_MUMU,
        Observables.BR_BD_MUMU,
        Observables.BR_BU_TAU_NU,
    ]

    # ---- 1) lance le worker stats dans un process séparé
    ctx = mp.get_context("spawn")
    q = ctx.Queue()

    p = ctx.Process(target=stats_worker, args=(lha_file_path, selected, q))
    p.start()

    status, payload = q.get()   # attend le résultat
    p.join()

    if status != "ok":
        raise RuntimeError(f"Stats worker failed: {payload}")

    summaries_raw = payload
    print("✅ summaries reçues du worker:", type(summaries_raw), "len=", len(summaries_raw))

    # ---- 2) calcule les valeurs centrales dans le process principal
    centrals = compute_centrals_in_main(lha_file_path, selected)
    for o, vals in centrals.items():
        print("central", o, "->", vals)

    # ---- 3) maintenant tu fais ton normalize + ton plot
    # summaries = normalize_summaries_keys(summaries_raw)
    # ... etc ...


if __name__ == "__main__":
    main()
