#include <iostream>
#include <cstdlib>
#include "WilsonUtils.h"
#include "config.hpp"



int main() {
    Logger* logger = Logger::getInstance();

    if (std::getenv("DISABLE_LOGGER")) {
        logger->setEnabled(false);
    }
    
    std::string root_file = project_root.data();

    double tolerance = 0.01;
    
    LOG_INFO("Running LO SM Wilson Coefficients Tests");
    runTest("LO", root_file + "Test/csv/sm/WilsonCoefficients_LO.csv", root_file + "Test/csv/superiso/sm/WilsonCoefficients_LO.csv", "SM", tolerance);
    LOG_INFO("Running NLO SM Wilson Coefficients Tests");
    runTest("NLO", root_file + "Test/csv/sm/WilsonCoefficients_NLO.csv", root_file + "Test/csv/superiso/sm/WilsonCoefficients_NLO.csv", "SM",tolerance);
    LOG_INFO("Running NNLO SM Wilson Coefficients Tests");
    runTest("NNLO", root_file + "Test/csv/sm/WilsonCoefficients_NNLO.csv", root_file + "Test/csv/superiso/sm/WilsonCoefficients_NNLO.csv", "SM",tolerance);

    return 0;
}
