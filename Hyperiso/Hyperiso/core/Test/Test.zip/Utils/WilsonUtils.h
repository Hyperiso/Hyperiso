#ifndef WILSON_UTILS_H
#define WILSON_UTILS_H

#include <string>
#include <memory>
#include "WilsonManager.h"
#include "BWilsonTHDM.h"
#include "BWilsonSUSY.h"
// #include "Wilson.h"
// #include "Wilson_susy.h"
// #include "Wilson_THDM.h"

void writeCoefficientsToFile(const std::string& strat_name, const std::string& fileName, double Q_match, const std::string& model);
void writeCoefficientsPrimeCQToFile(const std::string& strat_name, const std::string& fileName, double Q_match, const std::string& model);
void writeRunCoefficientsToFile(const std::string& strat_name, const std::string& fileName, double Q_match, double Q, const std::string& model, int base);
void runTest(const std::string& strategyName, const std::string& testFile, const std::string& referenceFile,const std::string& model, double tolerance, bool PrimeCQ = false, int run = 0);

#endif // WILSON_UTILS_H

