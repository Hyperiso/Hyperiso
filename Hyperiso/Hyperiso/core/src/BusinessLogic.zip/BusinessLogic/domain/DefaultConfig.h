#pragma once

struct DecayConfig {

};